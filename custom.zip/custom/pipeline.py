
from kfp.dsl import pipeline
from components import preprocess, train
from google.cloud import aiplatform
from kfp import compiler
import config
@pipeline(name="mortgage-data-classification")
def mortgage_pipeline(
    bq_table: str = "mdepew-assets.synthetic.synthetic_mortgage_data",
    target_column: str = "refinance",  # Update with your target column name
):
    # Preprocessing component
    preprocess_task = preprocess.preprocess_bq_data(
        bq_table=bq_table
    ).set_caching_options(False)

    # Training component
    train_task = train.train_binary_model(
        input_data=preprocess_task.outputs["output_data"],
        target_column=target_column
    ).after(preprocess_task)


pipeline_file = "mortgage_pipeline.json"
compiler.Compiler().compile(
    pipeline_func=mortgage_pipeline,
    package_path=pipeline_file
)

# Submit the pipeline to Vertex AI
aiplatform.init(project=config.PROJECT_ID, location=config.REGION)

aiplatform.PipelineJob(
    display_name="mortgage-data-pipeline",
    template_path=pipeline_file,
    pipeline_root="gs://" + config.PROJECT_ID + "/pipeline_root/",
).run()


