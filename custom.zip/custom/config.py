PROJECT_ID = "mdepew-assets"
VERSION="1"
BUCKET_URI = f"gs://{PROJECT_ID}-xgboost-classification"
DATASET_ID = "synthetic"  # The Data Set ID where the view sits
VIEW_NAME = "synthetic_data"  #
PIPELINE_ROOT = f"{BUCKET_URI}/pipeline_root/" 
TABLE_NAME= "synthetic_mortgage_data"
MODEL_NAME="refinance-classifier"
REGION="us-central1"
ENDPOINT_NAME="refinance-classifier"
hptune=True
MODEL_PATH=f"{BUCKET_URI}/models/{MODEL_NAME}-{VERSION}"

# This is where all pipeline artifacts are sent. You'll need to ensure the bucket is created ahead of time

