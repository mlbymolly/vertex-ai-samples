from kfp.dsl import Dataset, Input, Output, component, Model, Metrics


@component(
    base_image="python:3.10",
    packages_to_install=["pandas", 
                         "pyarrow", 
                         "kfp", 
                         "xgboost", 
                         "scikit-learn"],
)
def evaluate_model(
    model: Input[Model],
    test_data: Input[Dataset],
    metrics: Output[Metrics]
):
    import pandas as pd
    import joblib
    from sklearn.metrics import accuracy_score

    df = pd.read_csv(test_data.path)
    X_test = df.drop("refinance", axis=1).values
    y_test = df["refinance"].values

    loaded_model = joblib.load(f"{model.path}/model.joblib")

    preds = loaded_model.predict(X_test)
    accuracy = accuracy_score(y_test, preds)
    metrics.log_metric("accuracy", accuracy)
