from kfp.components import Dataset, Output, component


@component(
    base_image="python:3.10",
    packages_to_install=[
        "pandas",
        "kfp",
        "db-dtypes",
        "gcsfs",
        "pyarrow",
        "google-cloud-bigquery",
    ],
)
def export_dataset(
    project_id: str, dataset_id: str, view_name: str, dataset: Output[Dataset]
):
    from google.cloud import bigquery

    client = bigquery.Client(project=project_id)
    query = f"SELECT * FROM `{project_id}.{dataset_id}.{view_name}`"
    query_job = client.query(query)
    df = query_job.result().to_dataframe()

    df.to_csv(dataset.path, index=False)
