from kfp.dsl import Dataset, Input, Output, component, Model, Metrics


@component(
    base_image="python:3.10",
    packages_to_install=["pandas", "pyarrow", "kfp", "xgboost", "scikit-learn"],
)
def train_binary_model(
    dataset: Input[Dataset],
    model_path: str,
    model: Output[Model],
    metrics: Output[Metrics],
):
    from sklearn.model_selection import train_test_split
    import pandas as pd
    import xgboost as xgb
    import joblib
    import os
    from sklearn.metrics import accuracy_score, roc_auc_score, precision_recall_curve

    df = pd.read_csv(dataset.path)
    X = df.drop("refinance", axis=1).values
    y = df["refinance"].values
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    model = xgb.XGBClassifier(n_estimators=100)
    model.fit(X_train, y_train)

    model.path = os.path.join(model_path, "model.joblib")

    os.makedirs(model.path, exist_ok=True)
    joblib.dump(model, os.path.join(model.path, "model.joblib"))

    predictions = model.predict(X_test)
    score = accuracy_score(y_test, predictions)
    auc = roc_auc_score(y_test, predictions)
    _ = precision_recall_curve(y_test, predictions)

    metrics.log_metric("accuracy", (score * 100.0))
    metrics.log_metric("framework", "xgboost")
    metrics.log_metric("dataset_size", len(df))
    metrics.log_metric("AUC", auc)
    print(f"Model saved to: {model.path}")
