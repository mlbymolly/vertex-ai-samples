from kfp.dsl import component


@component(
    base_image="python:3.10",
    packages_to_install=["pandas", "pyarrow", "google-cloud-bigquery"],
)
def create_bq_view(project_id: str, dataset_id: str, view_name: str, table_name: str):
    from google.cloud import bigquery

    client = bigquery.Client(project=project_id)
    create_view_query = f"""
        CREATE OR REPLACE VIEW `{dataset_id}.{view_name}` AS
        SELECT
        interest_rate,
        loan_amount,
        loan_balance,
        loan_to_value_ratio,
        credit_score,
        debt_to_income_ratio,
        income,
        loan_term,
        loan_age,
        home_value,
        current_rate,
        rate_spread,
        refinance
        FROM `{project_id}.{dataset_id}.{table_name}`
    """
    job = client.query(create_view_query)
    job.result()
