from google.cloud import aiplatform

import kfp
from kfp import dsl
from kfp.dsl import (
    Input,
    Output,
    Dataset,
    Model,
    Metrics,
    Artifact,
    component,
)

PIPELINE_ROOT = "gs://mdepew-assets-xgboost-classification/pipeline_root/"
PROJECT_ID = "mdepew-assets"
REGION = "us-central1"

@component(
    base_image="python:3.10",
    packages_to_install=["google-cloud-bigquery", "pandas"]
)
def create_bq_view(
    project_id: str,
    dataset_id: str,
    table_name: str,
    view_name: str
):
    """Creates a BigQuery view."""
    from google.cloud import bigquery
    client = bigquery.Client(project=project_id)
    
    create_or_replace_view = f"""
        CREATE OR REPLACE VIEW
        `{dataset_id}.{view_name}` AS
        SELECT
        interest_rate,
        loan_amount,
        loan_balance,
        loan_to_value_ratio,
        credit_score,
        debt_to_income_ratio,
        income,
        loan_term,
        loan_age,
        home_value,
        current_rate,
        rate_spread,
        refinance
        FROM `{project_id}.{dataset_id}.{table_name}`
    """
    
    query_job = client.query(create_or_replace_view)
    query_job.result()


@component(
    base_image="python:3.10",
    packages_to_install=["google-cloud-bigquery[pandas]", "pandas"]
)
def export_dataset(
    project_id: str,
    dataset_id: str,
    view_name: str,
    dataset: Output[Dataset]
):
    """Exports data from BigQuery view to CSV."""
    from google.cloud import bigquery
    import pandas as pd

    client = bigquery.Client(project=project_id)
    query = f"SELECT * FROM `{project_id}.{dataset_id}.{view_name}`"
    df = client.query(query).to_dataframe()
    df.to_csv(dataset.path, index=False)


@component(
    base_image="python:3.10",
    packages_to_install=["xgboost", "pandas", "joblib", "scikit-learn"]
)
def xgboost_training(
    dataset: Input[Dataset],
    model: Output[Model],
    metrics: Output[Metrics]
):
    """Trains an XGBoost model."""
    import os
    import pandas as pd
    import joblib
    import xgboost as xgb
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, roc_auc_score, precision_recall_curve

    # Load dataset
    raw_data = pd.read_csv(dataset.path)

    LABEL_COLUMN = "refinance"
    POSITIVE_VALUE = 1

    X = raw_data.drop([LABEL_COLUMN], axis=1)
    y = (raw_data[LABEL_COLUMN] == POSITIVE_VALUE).astype(int)

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

    params = {
        "reg_lambda": [0, 1],
        "gamma": [1, 2],
        "max_depth": [3, 5, 10],
        "learning_rate": [0.1, 0.01],
    }

    xgb_model = xgb.XGBClassifier(n_estimators=50, objective="binary:logistic")
    xgb_model.fit(X_train, y_train)

    predictions = xgb_model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    auc = roc_auc_score(y_test, predictions)

    metrics.log_metric("accuracy", accuracy)
    metrics.log_metric("auc", auc)

    os.makedirs(model.path, exist_ok=True)
    joblib.dump(xgb_model, os.path.join(model.path, "model.joblib"))


@component(
    base_image="python:3.10",
    packages_to_install=["xgboost", "pandas", "joblib", "scikit-learn"]
)
def evaluate_model(
    model: Input[Model],
    test_data: Input[Dataset],
    metrics: Output[Metrics]
):
    """Evaluates the model."""
    import joblib
    import pandas as pd
    from sklearn.metrics import accuracy_score

    # Load model and test data
    model = joblib.load(f"{model.path}/model.joblib")
    test_data = pd.read_csv(test_data.path)

    X_test = test_data.drop(columns=["refinance"])
    y_test = test_data["refinance"]

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)

    metrics.log_metric("accuracy", accuracy)


@component(
    base_image="python:3.10",
    packages_to_install=["google-cloud-aiplatform"]
)
def deploy_xgboost_model(
    model: Input[Model],
    project_id: str,
    vertex_endpoint: Output[Artifact],
    vertex_model: Output[Model]
):
    """Deploys the model to Vertex AI."""
    from google.cloud import aiplatform

    aiplatform.init(project=project_id)

    deployed_model = aiplatform.Model.upload(
        display_name="classification-demo-model",
        artifact_uri=model.uri,
        serving_container_image_uri="us-docker.pkg.dev/vertex-ai/prediction/xgboost-cpu.1-7:latest",
    )

    endpoint = deployed_model.deploy(machine_type="n1-standard-4")

    vertex_endpoint.uri = endpoint.resource_name
    vertex_model.uri = deployed_model.resource_name


@dsl.pipeline(
    name="classification-demo-pipeline",
    description="Pipeline to train, evaluate, and deploy an XGBoost model."
)
def classification_demo_pipeline():
    create_view_task = create_bq_view(
        project_id=PROJECT_ID,
        dataset_id="synthetic",
        table_name="synthetic_mortgage_data",
        view_name="synthetic_data",
    )

    export_data_task = export_dataset(
        project_id=PROJECT_ID,
        dataset_id="synthetic",
        view_name="synthetic_data"
    )

    train_task = xgboost_training(
        dataset=export_data_task.outputs["dataset"]
    )

    evaluate_task = evaluate_model(
        model=train_task.outputs["model"],
        test_data=export_data_task.outputs["dataset"]
    )

    deploy_task = deploy_xgboost_model(
        model=train_task.outputs["model"],
        project_id=PROJECT_ID
    )


# Compile the pipeline
kfp.compiler.Compiler().compile(
    pipeline_func=classification_demo_pipeline,
    package_path="classification_demo_pipeline.json"
)



# Run the pipeline

pipeline = aiplatform.PipelineJob(
    display_name="classification-demo-pipeline",
    template_path="classification_demo_pipeline.json",
)
pipeline.run()